package com.example.emergenseek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.os.Bundle;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class SecondActivity2 extends AppCompatActivity {
    Button button;
    EditText editText2;
    EditText editText3;
    EditText editText4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second2);
        //editText2 = (EditText) findViewById(R.id.editText2);
       // editText3 = (EditText) findViewById(R.id.editText3);
       // editText4 = (EditText) findViewById(R.id.editText4);
        button = findViewById(R.id.button7);

        }
    public void onClickIntent(View view) {
        // Code here executes on main thread after user presses button
        //startActivity(new Intent(SecondActivity2.this, ThirdActivity2.class));
        Intent i = new Intent(SecondActivity2.this, ThirdActivity2.class);
        editText2 = (EditText) findViewById(R.id.editText2);
        editText3 = (EditText) findViewById(R.id.editText3);
        editText4 = (EditText) findViewById(R.id.editText4);
        String location1 = editText2.getText().toString();
        String hospital1 = editText3.getText().toString();
        String hotline1 = editText4.getText().toString();
        i.putExtra("Location1: ", location1);
        i.putExtra("Hospital1: ", hospital1);
        i.putExtra("Hotline1: ", hotline1);

        Bundle extras = new Bundle();
        i.putExtras(extras);
        startActivity(i);
    }
}

    /*public void onClickIntent(View view) {
                String location1 = editText2.getText().toString();
                String hospital1 = editText3.getText().toString();
                String hotline1 = editText4.getText().toString();

                try{
                    FileOutputStream fOut = openFileOutput("location1.txt", MODE_WORLD_READABLE);
                    OutputStreamWriter osw = new OutputStreamWriter((fOut));
                    osw.write(location1);
                    osw.flush();
                    osw.close();
                }
                catch(IOException ioe)
                {
                    ioe.printStackTrace();
                }
        startActivity(new Intent(SecondActivity2.this, ThirdActivity2.class));
        }*/





