package com.example.emergenseek;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Bundle;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileInputStream;

public class ThirdActivity2 extends AppCompatActivity {

    static final int READ_BLOCK_SIZE = 100;
    TextView editText2;
    EditText editText3;
    EditText editText4;
    EditText editText5;
    EditText editText6;
    TextView text11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third2);

        final Button button1 = findViewById(R.id.button5);

        editText2 = (EditText) findViewById(R.id.editText2);
        editText3 = (EditText) findViewById(R.id.editText3);
        editText4 = (EditText) findViewById(R.id.editText4);
        editText5 = (EditText) findViewById(R.id.editText5);


        Intent i2 = getIntent();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String cLocation1 = i2.getStringExtra("Location1");
            String cHospital1 = i2.getStringExtra("Hospital1");
            String cHotline1 = i2.getStringExtra("Hotline1");
            text11 = (TextView) findViewById(R.id.textView7);
            text11.setText(cLocation1);
            editText3.setText(cHospital1);
            editText4.setText(cHotline1);
        }
        //String location1 = getString(R.string.location1);
        //String hospital1 = getString(R.string.hospital1);
        //String hotline1 = getString(R.string.hotline1);

    }
}
